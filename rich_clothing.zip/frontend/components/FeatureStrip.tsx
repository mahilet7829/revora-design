const FEATURES = [
  { title: "Premium Quality", desc: "Soft, durable, comfortable" },
  { title: "Custom Printing", desc: "Your design, your style" },
  { title: "Worldwide Shipping", desc: "Get your order anywhere" },
  { title: "Secure Payment", desc: "Shop with confidence" },
];

export default function FeatureStrip() {
  return (
    <section className="feature-strip">
      {FEATURES.map((f) => (
        <div key={f.title} className="feature-item">
          <h4>{f.title}</h4>
          <p>{f.desc}</p>
        </div>
      ))}
    </section>
  );
}