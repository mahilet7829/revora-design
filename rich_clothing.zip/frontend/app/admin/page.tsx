"use client";

import { useEffect, useState } from "react";

export default function AdminDashboard() {
  const [products, setProducts] = useState<any[]>([]);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  async function loadProducts() {
    const res = await fetch("/api/products");
    setProducts(await res.json());
  }

  useEffect(() => {
    loadProducts();
  }, []);

  async function addProduct(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return alert("Please select an image");
    setUploading(true);

    const formData = new FormData();
    formData.append("file", file);
    const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
    const { url } = await uploadRes.json();

    await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, description, price, imageUrl: url }),
    });

    setName("");
    setDescription("");
    setPrice("");
    setFile(null);
    setUploading(false);
    loadProducts();
  }

  async function deleteProduct(id: string) {
    if (!confirm("Delete this item?")) return;
    await fetch(`/api/products/${id}`, { method: "DELETE" });
    loadProducts();
  }

  return (
    <main className="container">
      <h1>Admin — Manage Clothes</h1>

      <form onSubmit={addProduct} className="admin-form">
        <input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
        <textarea
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          required
        />
        <input
          type="file"
          accept="image/*"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          required
        />
        <button type="submit" disabled={uploading}>
          {uploading ? "Uploading..." : "Add Product"}
        </button>
      </form>

      <div className="admin-list">
        {products.map((p) => (
          <div key={p.id} className="admin-item">
            <img src={p.imageUrl} alt={p.name} width={60} height={60} style={{ objectFit: "cover" }} />
            <span>{p.name} — ${p.price}</span>
            <button onClick={() => deleteProduct(p.id)}>Delete</button>
          </div>
        ))}
      </div>
    </main>
  );
}