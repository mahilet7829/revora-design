import { NextRequest, NextResponse } from "next/server";

export function middleware(req: NextRequest) {
  const isLoginPage = req.nextUrl.pathname === "/admin/login";
  const authCookie = req.cookies.get("admin_auth")?.value;

  if (!isLoginPage && authCookie !== process.env.ADMIN_PASSWORD) {
    const loginUrl = new URL("/admin/login", req.url);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};