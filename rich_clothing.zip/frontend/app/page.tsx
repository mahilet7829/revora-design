import { prisma } from "@/frontend/lib/prisma";
import ProductCard from "@/frontend/components/ProductCard";
import Hero from "@/frontend/components/Hero";
import FeatureStrip from "@/frontend/components/FeatureStrip";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const products = await prisma.product.findMany({ orderBy: { createdAt: "desc" } });

  return (
    <main>
      <Hero />
      <FeatureStrip />

      <section id="collection" className="section">
        <div className="section-header">
          <h2>Signature Collection</h2>
          <Link href="#collection" className="link-arrow">
            SHOP ALL →
          </Link>
        </div>

        <div className="product-grid">
          {products.length === 0 && <p className="empty-state">No products yet — add some from the admin page.</p>}
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      <section className="cta-split">
        <div className="cta-block dark">
          <h3>
            Bring Your Idea
            <br />
            to Life
          </h3>
          <p>Send us your design, logo or idea — we'll bring it to life with premium quality and perfect fit.</p>
          <Link href="/" className="btn-outline">
            START CUSTOM ORDER →
          </Link>
        </div>
        <div className="cta-block burgundy">
          <h3>Quality in Every Detail</h3>
        </div>
      </section>
    </main>
  );
}