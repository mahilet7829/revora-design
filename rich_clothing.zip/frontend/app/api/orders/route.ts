import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/frontend/lib/prisma";

export async function POST(req: NextRequest) {
  const { productId, customerName, customerPhone, size, quantity } = await req.json();

  if (!productId || !customerName || !customerPhone || !size || !quantity) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  const order = await prisma.order.create({
    data: {
      productId,
      customerName,
      customerPhone,
      size,
      quantity: parseInt(quantity),
    },
  });

  return NextResponse.json(order);
}