import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/frontend/lib/prisma";

export async function GET() {
  const products = await prisma.product.findMany({
    orderBy: { createdAt: "desc" },
    include: { reactions: true, reviews: true },
  });
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const authCookie = req.cookies.get("admin_auth")?.value;
  if (authCookie !== process.env.ADMIN_PASSWORD) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { name, description, price, imageUrl } = await req.json();

  const product = await prisma.product.create({
    data: {
      name,
      description,
      price: parseFloat(price),
      imageUrl,
      reactions: {
        create: [
          { type: "love", count: 0 },
          { type: "fire", count: 0 },
          { type: "wow", count: 0 },
          { type: "meh", count: 0 },
        ],
      },
    },
  });

  return NextResponse.json(product);
}