"use client";

import { useState } from "react";

type Review = { id: string; name: string; comment: string; rating: number; createdAt: string };

export default function ReviewSection({
  productId,
  initialReviews,
}: {
  productId: string;
  initialReviews: Review[];
}) {
  const [reviews, setReviews] = useState(initialReviews);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");
  const [rating, setRating] = useState(5);
  const [submitting, setSubmitting] = useState(false);

  async function submitReview(e: React.FormEvent) {
    e.preventDefault();
    if (!name || !comment) return;
    setSubmitting(true);

    const res = await fetch(`/api/products/${productId}/reviews`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, comment, rating }),
    });
    const newReview = await res.json();

    setReviews([newReview, ...reviews]);
    setName("");
    setComment("");
    setRating(5);
    setSubmitting(false);
  }

  return (
    <div className="review-section">
      <h3>Customer Feedback ({reviews.length})</h3>

      <form onSubmit={submitReview} className="review-form">
        <input
          placeholder="Your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <select value={rating} onChange={(e) => setRating(Number(e.target.value))}>
          {[5, 4, 3, 2, 1].map((n) => (
            <option key={n} value={n}>
              {"⭐".repeat(n)}
            </option>
          ))}
        </select>
        <textarea
          placeholder="Write your feedback..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          required
        />
        <button type="submit" disabled={submitting}>
          {submitting ? "Posting..." : "Post Feedback"}
        </button>
      </form>

      <div className="review-list">
        {reviews.length === 0 && <p>No feedback yet. Be the first!</p>}
        {reviews.map((r) => (
          <div key={r.id} className="review-item">
            <strong>{r.name}</strong> — {"⭐".repeat(r.rating)}
            <p>{r.comment}</p>
          </div>
        ))}
      </div>
    </div>
  );
}