"use client";

import { useState } from "react";

const REACTIONS = [
  { type: "love", emoji: "❤️" },
  { type: "fire", emoji: "🔥" },
  { type: "wow", emoji: "😍" },
  { type: "meh", emoji: "👎" },
];

export default function ReactionBar({
  productId,
  initialReactions,
}: {
  productId: string;
  initialReactions: { type: string; count: number }[];
}) {
  const [reactions, setReactions] = useState(initialReactions);
  const [clicked, setClicked] = useState<string[]>(
    typeof window !== "undefined"
      ? JSON.parse(localStorage.getItem(`reacted-${productId}`) || "[]")
      : []
  );

  async function react(type: string) {
    if (clicked.includes(type)) return;

    const res = await fetch(`/api/products/${productId}/reactions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type }),
    });
    const updated = await res.json();

    setReactions((prev) =>
      prev.map((r) => (r.type === type ? { ...r, count: updated.count } : r))
    );

    const newClicked = [...clicked, type];
    setClicked(newClicked);
    localStorage.setItem(`reacted-${productId}`, JSON.stringify(newClicked));
  }

  return (
    <div className="reaction-bar">
      {REACTIONS.map(({ type, emoji }) => {
        const count = reactions.find((r) => r.type === type)?.count || 0;
        return (
          <button
            key={type}
            onClick={() => react(type)}
            className={`reaction-btn ${clicked.includes(type) ? "reacted" : ""}`}
          >
            <span>{emoji}</span>
            <span>{count}</span>
          </button>
        );
      })}
    </div>
  );
}