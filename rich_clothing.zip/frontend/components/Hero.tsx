import Link from "next/link";

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-text">
        <p className="eyebrow">CUSTOM HOODIES & PRINTING</p>
        <h1>
          YOUR VISION.
          <br />
          OUR DESIGN.
        </h1>
        <p className="hero-sub">
          High-quality hoodies, custom prints and unique designs made for your style. Turn your ideas into
          something real.
        </p>
        <Link href="#collection" className="btn-primary">
          SHOP NOW →
        </Link>
      </div>
    </section>
  );
}