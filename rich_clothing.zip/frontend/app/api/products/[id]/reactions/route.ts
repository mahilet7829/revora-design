import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/frontend/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { type } = await req.json();
  const validTypes = ["love", "fire", "wow", "meh"];

  if (!validTypes.includes(type)) {
    return NextResponse.json({ error: "Invalid reaction type" }, { status: 400 });
  }

  const reaction = await prisma.reaction.upsert({
    where: { productId_type: { productId: params.id, type } },
    update: { count: { increment: 1 } },
    create: { productId: params.id, type, count: 1 },
  });

  return NextResponse.json(reaction);
}