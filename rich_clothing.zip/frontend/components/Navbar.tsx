import Link from "next/link";
import { Search, User, ShoppingBag } from "lucide-react";

export default function Navbar() {
  return (
    <header className="navbar">
      <Link href="/" className="brand">
        <span className="crown">♛</span> RICH CLOTHING
      </Link>

      <nav className="nav-links">
        <Link href="/">Home</Link>
        <Link href="/">Shop</Link>
        <Link href="/">Custom Design</Link>
        <Link href="/">About</Link>
        <Link href="/">Contact</Link>
      </nav>

      <div className="nav-icons">
        <Search size={18} />
        <User size={18} />
        <ShoppingBag size={18} />
      </div>
    </header>
  );
}