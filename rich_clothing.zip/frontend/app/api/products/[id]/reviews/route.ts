import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/frontend/lib/prisma";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const { name, comment, rating } = await req.json();

  if (!name || !comment || !rating) {
    return NextResponse.json({ error: "Missing fields" }, { status: 400 });
  }

  const review = await prisma.review.create({
    data: {
      name,
      comment,
      rating: parseInt(rating),
      productId: params.id,
    },
  });

  return NextResponse.json(review);
}