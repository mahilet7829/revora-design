import Link from "next/link";
import Image from "next/image";
import { Heart } from "lucide-react";

export default function ProductCard({ product }: { product: any }) {
  return (
    <Link href={`/product/${product.id}`} className="product-card">
      <div className="product-image">
        <Image src={product.imageUrl} alt={product.name} fill style={{ objectFit: "cover" }} />
        <button className="wishlist-icon" onClick={(e) => e.preventDefault()}>
          <Heart size={16} />
        </button>
      </div>
      <h3>{product.name}</h3>
      <p>${product.price.toFixed(2)}</p>
    </Link>
  );
}