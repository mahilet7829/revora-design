export default function Footer() {
  const socials = [
    {
      label: "Instagram",
      href: "#",
      svg: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="2" y="2" width="20" height="20" rx="5" />
          <circle cx="12" cy="12" r="4" />
          <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
        </svg>
      ),
    },
    {
      label: "Facebook",
      href: "#",
      svg: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
        </svg>
      ),
    },
    {
      label: "Twitter",
      href: "#",
      svg: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z" />
        </svg>
      ),
    },
    {
      label: "YouTube",
      href: "#",
      svg: (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <rect x="2" y="5" width="20" height="14" rx="4" />
          <polygon points="10,9 15,12 10,15" fill="currentColor" stroke="none" />
        </svg>
      ),
    },
  ];

  return (
    <footer className="site-footer">
      <div className="footer-brand">
        <span className="crown">♛</span> RICH CLOTHING
      </div>

      <div className="footer-links">
        <a href="/">Home</a>
        <a href="/">Shop</a>
        <a href="/">Custom Design</a>
        <a href="/">About</a>
        <a href="/">Contact</a>
      </div>

      <div className="footer-socials">
        {socials.map((s) => (
          <a key={s.label} href={s.href} aria-label={s.label}>
            {s.svg}
          </a>
        ))}
      </div>

      <p className="footer-copy">© {new Date().getFullYear()} Rich Clothing. All rights reserved.</p>
    </footer>
  );
}