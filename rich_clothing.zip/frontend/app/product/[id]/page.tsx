import { prisma } from "@/frontend/lib/prisma";
import Image from "next/image";
import ReactionBar from "@/frontend/components/ReactionBar";
import ReviewSection from "@/frontend/components/ReviewSection";
import WhatsAppOrderButton from "@/frontend/components/WhatsAppOrderButton";
import { notFound } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function ProductPage({ params }: { params: { id: string } }) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { reactions: true, reviews: { orderBy: { createdAt: "desc" } } },
  });

  if (!product) return notFound();

  return (
    <main className="container product-page">
      <div className="product-image-large">
        <Image src={product.imageUrl} alt={product.name} fill style={{ objectFit: "cover" }} />
      </div>

      <div className="product-details">
        <h1>{product.name}</h1>
        <p className="price">${product.price.toFixed(2)}</p>
        <p className="description">{product.description}</p>

        <ReactionBar productId={product.id} initialReactions={product.reactions} />
        <WhatsAppOrderButton productId={product.id} productName={product.name} price={product.price} />
      </div>

      <ReviewSection productId={product.id} initialReviews={product.reviews} />
    </main>
  );
}