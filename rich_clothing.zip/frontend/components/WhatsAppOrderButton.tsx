"use client";

import { useState } from "react";

export default function WhatsAppOrderButton({
  productId,
  productName,
  price,
}: {
  productId: string;
  productName: string;
  price: number;
}) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [size, setSize] = useState("M");
  const [quantity, setQuantity] = useState(1);
  const [open, setOpen] = useState(false);

  async function placeOrder(e: React.FormEvent) {
    e.preventDefault();

    await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId, customerName: name, customerPhone: phone, size, quantity }),
    });

    const message = `New Order from Rich Clothing:
Product: ${productName}
Price: $${price}
Size: ${size}
Quantity: ${quantity}
Customer: ${name}
Phone: ${phone}`;

    const waNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER;
    const url = `https://wa.me/${waNumber}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
    setOpen(false);
  }

  if (!open) {
    return (
      <button className="order-btn" onClick={() => setOpen(true)}>
        Order via WhatsApp
      </button>
    );
  }

  return (
    <form onSubmit={placeOrder} className="order-form">
      <input placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} required />
      <input placeholder="Your phone" value={phone} onChange={(e) => setPhone(e.target.value)} required />
      <select value={size} onChange={(e) => setSize(e.target.value)}>
        {["S", "M", "L", "XL", "XXL"].map((s) => (
          <option key={s}>{s}</option>
        ))}
      </select>
      <input
        type="number"
        min={1}
        value={quantity}
        onChange={(e) => setQuantity(Number(e.target.value))}
      />
      <button type="submit">Send Order to WhatsApp</button>
    </form>
  );
}